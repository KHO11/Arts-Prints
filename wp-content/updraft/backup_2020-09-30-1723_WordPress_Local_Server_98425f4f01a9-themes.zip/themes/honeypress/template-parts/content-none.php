<article id="post-<?php the_ID(); ?>" <?php post_class();?>>	
	<header class="entry-header">
		<h2 class="entry-title"><?php esc_html_e('Nothing found', 'honeypress'); ?></a></h2>
		<p><?php esc_html_e('Sorry, but nothing matched your search criteria. Please try again with some different keywords.','honeypress'); ?></p>
	</header>
</article>